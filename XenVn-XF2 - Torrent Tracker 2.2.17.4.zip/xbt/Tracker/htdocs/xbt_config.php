<?php
	$mysql['host'] = 'localhost';
	$mysql['user'] = 'xbt';
	$mysql['password'] = '';
	$mysql['db'] = 'xbt';
