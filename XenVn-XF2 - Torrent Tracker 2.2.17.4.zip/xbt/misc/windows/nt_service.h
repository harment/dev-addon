#pragma once

int nt_service_install(const char* name);
int nt_service_uninstall(const char* name);
